ELAIZA INOCENTES PORTFOLIO

Open index.html in a browser to view the portfolio.

Included:
- Responsive one-page portfolio
- Professional portrait and headshot from the supplied images
- About, work/case studies, sample dashboard, skills, experience, and contact sections
- Mobile navigation
- Scroll reveal animations
- Contact form that opens the visitor's email client

IMPORTANT:
The LinkedIn and GitHub buttons currently point to the generic LinkedIn/GitHub homepages because personal profile URLs were not provided. Replace those two href values in index.html with your actual profile URLs.
